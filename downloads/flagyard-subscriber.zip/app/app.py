from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
import os
import sqlite3
from flask import request, jsonify
import magic 
import random,time

app = Flask(__name__)
app.config.from_object('config.Config')
db = SQLAlchemy(app)



def create_database():
    db_path = app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
    if not os.path.exists(db_path):
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
                  CREATE TABLE subscribers (
                      id INTEGER PRIMARY KEY AUTOINCREMENT,
                      email TEXT NOT NULL UNIQUE,
                      update_frequency TEXT
                  )
              ''')
        cursor.execute('''
            CREATE TABLE feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                filename TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS updates_freq (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                option TEXT NOT NULL,
                freq TEXT NOT NULL
            )
        ''')
        options_data = [
            (0, 'Daily'),
            (1, 'Weekly'),
            (2, 'Monthly'),
            (3, '3-Months'),
            (4, '6-Months'),
            (5, '9-Months'),
            (6, 'Yearly')
        ]
        cursor.executemany('INSERT INTO updates_freq (option, freq) VALUES (?, ?)', options_data)
        conn.commit()
        conn.close()

def is_allowed_file(file_ext):
    allowed_extensions = {'.jpeg', '.jpg', '.png', '.pdf'}
    return file_ext in allowed_extensions

def filter_filename(filename):
    file_ext = os.path.splitext(filename)[1].lower()
    filename = filename.replace('.', '').replace('\\', '').replace('/','')
    filename += file_ext
    if is_allowed_file(file_ext):
        return filename
    else:
        return False

def get_mime(file) :
    mime = magic.Magic(mime=True)
    chunck_size  = 4 ; 
    file_bytes = b"" 
    while True : 
        chucnk = file.read(chunck_size) 
        if not chucnk :
            break 
        file_bytes +=chucnk
        if len(file_bytes) > 2048 :
            break 
    
    mime_type = mime.from_buffer(file_bytes)
    return mime_type


@app.before_first_request
def initialize_database():
    create_database()

@app.route('/')
def index():
    return render_template('index.html')





@app.route('/subscribe', methods=['GET', 'POST'])
def subscribe():
    if request.method == 'POST':
        try:
            email = request.form['email']
            update_option = request.form['updates_freq']
            conn = sqlite3.connect('site.db')
            conn.enable_load_extension(True)
            cursor = conn.cursor()
            cursor.execute(f"SELECT freq FROM updates_freq WHERE option = '{update_option}'")
            update_frequency = cursor.fetchone()
            conn.commit()
            conn.close()
            if update_frequency is None:
                result = {'message': 'Invalid update frequency option.', 'status': 'warning'}
            else:
                result = {'message': 'You have successfully subscribed!', 'status': 'success'}
            
            return jsonify(result), 200
        
        except KeyError:
            return jsonify({'message': 'Parameters missing', 'status': 'warning'}), 400
        except Exception as e: 
            return jsonify({'message': 'Error occurred 1' , 'status': 'warning'}), 400
    else:
        return render_template('subscribe.html')



@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        try :
            title = request.form['title']
            description = request.form['description']
            file = request.files['file']
            filename = None
            if file:
                filename = file.filename
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename.replace('/', '').replace('..','')))
                filtered_filename = filter_filename(filename)
                mime_type = get_mime(file)
                if not filtered_filename:
                    os.remove(os.path.join(app.config['UPLOAD_FOLDER'], filename.replace('/', '').replace('..','')))
                    return jsonify({'message': 'File type not allowed. Only PDF, JPEG, and PNG are allowed.', 'status': 'warning'}), 400
                else:
                    return jsonify({'message': 'File Upoaded successfully', 'status': 'success'}), 200
        except KeyError :
            return jsonify({'message': 'Parameters missing', 'status': 'warning'}), 400
        except :
            return jsonify({'message': 'Error occured 2', 'status': 'warning'}), 400

    else:
        return render_template('feedback.html')

    conn = sqlite3.connect('site.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO feedback (title, description, filename) VALUES (?, ?, ?)',
                   (title, description, filename))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Your feedback has been submitted!', 'status': 'success'}), 200

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    app.run(port=5000, host='0.0.0.0')
